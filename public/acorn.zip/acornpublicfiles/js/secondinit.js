(function($){
  $(function(){
 $('.button-collapse').sideNav({
      menuWidth: 200,
	  edge: 'left', // <--- CHECK THIS OUT
    }
  );

  }); // end of document ready
})(jQuery); // end of jQuery name space