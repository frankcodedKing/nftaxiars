function emptyElement(x){
_("err").style.display = "none";
_(x).innerHTML = "";
}