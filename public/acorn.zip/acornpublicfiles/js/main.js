// this targets all div by its id

function _(x){
	return document.getElementById(x);
}
